/*
* Course: CS 100 Fall 2013
*
* First Name: Luis
* Last Name: Garcia
* Username: lgarc018
* email address: lgarc018@ucr.edu
*
*
* Assignment: HW2
*
* I hereby certify that the contents of this file represent
* my own original individual work. Nowhere herein is there
* code from any outside resources such as another individual,
* a website, or publishings unless specifically designated as
* permissible by the instructor or TA.
*/
#include "Coins.h"
#include <iostream>
using namespace std;

const int CENTS_FOR_CANDYBAR = 482;

int main()
{
    //creats a coins object called pocket
    //hwo carries 100 quarters S:
    Coins pocket (100, 10, 10, 100);

    cout << "I started with " << pocket << "in my pocket" << endl;

    //Creates a coins object called payForCandy and intializes it
    Coins payForCandy = pocket.extractChange(CENTS_FOR_CANDYBAR);
    
    cout << "I bought a candy bar for " << CENTS_FOR_CANDYBAR
         << " cents using " << payForCandy << endl;
    cout << "I have " << pocket << " left in my pocket" << endl;
    return 0;
}
