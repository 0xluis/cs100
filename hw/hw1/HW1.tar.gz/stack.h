/*
* Course: CS 100 Fall 2013
*
* First Name: Luis
* Last Name: Garcia
* Username: lgarc018
* email address: lgarc018@ucr.edu
*
*   
* Assignment: HW1
*
* I hereby certify that the contents of this file represent
* my own original individual work. Nowhere herein is there
* code from any outside resources such as another individual,
* a website, or publishings unless specifically designated as
* permissible by the instructor or TA.
*/

#define STACK_CAPACITY 1000
#include <iostream>
using namespace std;

class Stack
{
    private:
	char* stackArray;
	int size;

    public:
	Stack()
	:stackArray(NULL), size(0)
	{
	    //set dynamic array
	    stackArray = new char [STACK_CAPACITY];
	}
	
	//standard push back function couts error if reaches 1000 chars
	void push(char c)
	{
	    if(size < STACK_CAPACITY)
	    {
	    	stackArray[size] = c;
	        size++;
	    }else{
        	cout << "The stack has reached it's maximum capacity!" << endl;
	    }
	}
	
	//standard pop function couts error if stack is empty
	//returns top char
	char pop()
	{
	    if(size > 0)
	    {
		size--;
		return stackArray[size];
	    }else{
		cout << "The stack is empty, cannot pop!" << endl;
	    }
	}
	
	//returns top char but doesnt pop it
	char top()
	{
	    if(size > 0)
	    {
		return stackArray[size-1];
	    }else{
		cout << "The stack is empty, there is no top!" << endl;
	    }
	}
	
	//is stack empty???
	bool isEmpty()
	{
	    return size == 0;
	}
	
	//deallocate
	~Stack()
	{
	    delete [] stackArray;
	}
};
