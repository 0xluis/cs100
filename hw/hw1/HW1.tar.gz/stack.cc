/*
* Course: CS 100 Fall 2013
*
* First Name: Luis
* Last Name: Garcia
* Username: lgarc018
* email address: lgarc018@ucr.edu
*
*   
* Assignment: HW1
*
* I hereby certify that the contents of this file represent
* my own original individual work. Nowhere herein is there
* code from any outside resources such as another individual,
* a website, or publishings unless specifically designated as
* permissible by the instructor or TA.
*/


#include "stack.h"
#include <iostream>
using namespace std;

int main()
{
    //Create a stack
    Stack stackOfChars;

    string input;
    //get input from user repeatedly until ^D input
    cout << "Press enter to push into stack, ^D to end\n";
    while(cin >> input)
    {     
    	//once the user stops entering a string "enter"
    	//push back the  chars into a stack
    	for(int i=0; i<input.size(); i++)
    	{
	    stackOfChars.push(input.at(i));
    	}
    }
    
    //cout << endl;
    //print the characters in reverse order
    while(!stackOfChars.isEmpty())
    {
	cout << stackOfChars.pop();
    }
    
    cout << endl;
}
