// FLAGS ARE AS FOLLOWS
// ./a.out file1 file2 file3 .... // delets specifided files
// ./a.out -a dir  //deltes all files within dir
// ./a.out -a -s dir //deletes all files within dir and its sub directories

#include <iostream>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
using namespace std;


void rDel (string directory, bool sub = true);

int main(int argc, char* argv[])
{
   if(argc == 1) 
   {
   	cout << "missing operand\n";
 	return 0;
   }

   if(string(argv[1]) == "-a")
   {
	if(argc > 3 && string(argv[2]) == "-s")
	{
	    //If we want to delete everything in a directory
            //including its sub directories
            rDel(argv[3], true);
           
	}
        else
	    rDel(argv[2]);
   }
   else
   for(int i=1; i<argc; i++)
   {
	unlink(argv[i]);
   }
   
}

void rDel(string directory, bool sub)
{
   DIR* dir = opendir(directory.c_str());
  
   struct stat fileInfo;
   if(lstat(directory.c_str(), &fileInfo)!=0)
   {
	cout << "Error file " << directory << " does not exist\n";
        return;
   }
   //else if(!S_ISDIR(fileInfo.st_mode))
   	//unlink(directory.c_str());
   else
   {   
        dirent* direntp = NULL;
   	while((direntp = readdir(dir)))
        {
            string filen = direntp->d_name;
            if(filen == "." || filen == "..")
		continue;
            string path = directory + "/" + filen;
            if(direntp->d_type & DT_DIR)
            {
                //string path = directory + "/" + filen;
                //char *cpath = new char [path.length()+1];
                //strcpy(cpath, path.c_str());
                rDel(path, false);
                //delete [] cpath;
            }
            else
               {
                cerr << path << endl;
                unlink(path.c_str());
                //cout << path << endl;
                }
        }
       if(!sub)
        rmdir(directory.c_str());
   }
}
