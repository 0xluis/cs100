//ARGUMENTS ARE AS FOLLOWS
//mv file1 file2 //renames file1 to file2
//mv file1 dir   //mvs file1 inside of dir

#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <iostream>
using namespace std;

int main(int argc, char* argv[])
{
    if(argc < 3)
	cout << "Errroorr needs 2 arguments 1st must be a file ie ./a.out file1 file2\n";
    else if (argc > 3)
         cout << "Error needs 2 arguemnts 1st must be a file ie ./a.out file1 file2\n";
    else
    {
        DIR* dir = opendir(argv[2]);
        struct stat fileInfo;

        if(S_ISDIR(fileInfo.st_mode))
        {
            string newpath = string(argv[2]) + string(argv[1]);
            link(argv[1], newpath.c_str());
        }
        else
        {

	     link(argv[1], argv[2]);
             unlink(argv[1]);
        }
    }
}
